-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2020 at 08:39 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ncoe_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `al_pirivena`
--

CREATE TABLE `al_pirivena` (
  `AL_index` varchar(255) NOT NULL,
  `stream` int(11) NOT NULL,
  `Year` varchar(11) NOT NULL,
  `attempt` int(11) NOT NULL,
  `sub1` varchar(11) NOT NULL,
  `grade1` varchar(2) NOT NULL,
  `sub2` varchar(11) NOT NULL,
  `grade2` varchar(2) NOT NULL,
  `sub3` varchar(11) NOT NULL,
  `grade3` varchar(2) NOT NULL,
  `sub4` varchar(11) DEFAULT NULL,
  `grade4` varchar(2) DEFAULT NULL,
  `gentst` int(11) DEFAULT NULL,
  `medium` varchar(2) NOT NULL,
  `zscore` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `al_result`
--

CREATE TABLE `al_result` (
  `AL_index` varchar(255) NOT NULL,
  `stream` int(11) NOT NULL,
  `attempt` int(11) NOT NULL,
  `sub1` varchar(11) NOT NULL,
  `grade1` varchar(2) NOT NULL,
  `sub2` varchar(11) NOT NULL,
  `grade2` varchar(2) NOT NULL,
  `sub3` varchar(11) NOT NULL,
  `grade3` varchar(2) NOT NULL,
  `sub4` varchar(11) NOT NULL,
  `grade4` varchar(2) NOT NULL,
  `gentst` int(11) NOT NULL,
  `medium` varchar(2) NOT NULL,
  `zscore` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_no` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `medium` int(11) NOT NULL,
  `pe_course` int(11) DEFAULT NULL,
  `religion_course` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `courseselect`
--

CREATE TABLE `courseselect` (
  `id` int(11) NOT NULL,
  `stuid` int(11) NOT NULL,
  `pref1` int(11) NOT NULL,
  `pref2` int(11) NOT NULL,
  `pref3` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filenamer` varchar(255) NOT NULL,
  `filenamew` varchar(255) DEFAULT NULL,
  `category` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ol_result`
--

CREATE TABLE `ol_result` (
  `OL_index` varchar(255) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `sub1` varchar(11) DEFAULT NULL,
  `grade1` varchar(2) DEFAULT NULL,
  `sub2` varchar(11) DEFAULT NULL,
  `grade2` varchar(2) DEFAULT NULL,
  `sub3` varchar(11) DEFAULT NULL,
  `grade3` varchar(2) DEFAULT NULL,
  `sub4` varchar(11) DEFAULT NULL,
  `grade4` varchar(2) DEFAULT NULL,
  `sub5` varchar(11) DEFAULT NULL,
  `grade5` varchar(2) DEFAULT NULL,
  `sub6` varchar(11) DEFAULT NULL,
  `grade6` varchar(2) DEFAULT NULL,
  `sub7` varchar(11) DEFAULT NULL,
  `grade7` varchar(2) DEFAULT NULL,
  `sub8` varchar(11) DEFAULT NULL,
  `grade8` varchar(2) DEFAULT NULL,
  `sub9` varchar(11) DEFAULT NULL,
  `grade9` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stuents`
--

CREATE TABLE `stuents` (
  `id` int(20) NOT NULL,
  `ALindex` varchar(255) NOT NULL,
  `OLindex1` varchar(255) NOT NULL,
  `OLindex2` varchar(255) DEFAULT NULL,
  `OLindex3` varchar(255) DEFAULT NULL,
  `sripadancoe` int(11) DEFAULT NULL,
  `stateworker` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `namewithinitials` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `Addressl1` varchar(255) DEFAULT NULL,
  `Addressl2` varchar(255) DEFAULT NULL,
  `Addressl3` varchar(255) DEFAULT NULL,
  `Addressl4` varchar(255) DEFAULT NULL,
  `Resdistrict` varchar(255) DEFAULT NULL,
  `NIC` varchar(12) DEFAULT NULL,
  `Gender` varchar(6) NOT NULL,
  `Title` varchar(10) NOT NULL,
  `Ethnicity` varchar(10) NOT NULL,
  `Mobile` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `git` varchar(11) DEFAULT NULL,
  `pirivena` int(11) DEFAULT NULL,
  `pemarks` int(11) DEFAULT NULL,
  `file1` varchar(255) DEFAULT NULL,
  `file2` varchar(255) DEFAULT NULL,
  `file3` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `al_pirivena`
--
ALTER TABLE `al_pirivena`
  ADD PRIMARY KEY (`AL_index`);

--
-- Indexes for table `al_result`
--
ALTER TABLE `al_result`
  ADD PRIMARY KEY (`AL_index`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_no` (`course_no`);

--
-- Indexes for table `courseselect`
--
ALTER TABLE `courseselect`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stuid` (`stuid`),
  ADD KEY `pref1` (`pref1`,`pref2`,`pref3`),
  ADD KEY `pref2` (`pref2`),
  ADD KEY `pref3` (`pref3`);

--
-- Indexes for table `ol_result`
--
ALTER TABLE `ol_result`
  ADD PRIMARY KEY (`OL_index`);

--
-- Indexes for table `stuents`
--
ALTER TABLE `stuents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ALindex` (`ALindex`),
  ADD KEY `OLindex1` (`OLindex1`),
  ADD KEY `OLindex2` (`OLindex2`),
  ADD KEY `OLindex3` (`OLindex3`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `courseselect`
--
ALTER TABLE `courseselect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stuents`
--
ALTER TABLE `stuents`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
